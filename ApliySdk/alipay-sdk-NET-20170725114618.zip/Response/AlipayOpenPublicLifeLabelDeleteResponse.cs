using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenPublicLifeLabelDeleteResponse.
    /// </summary>
    public class AlipayOpenPublicLifeLabelDeleteResponse : AopResponse
    {
    }
}
