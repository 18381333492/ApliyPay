using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayDaoweiOrderModifyResponse.
    /// </summary>
    public class AlipayDaoweiOrderModifyResponse : AopResponse
    {
    }
}
