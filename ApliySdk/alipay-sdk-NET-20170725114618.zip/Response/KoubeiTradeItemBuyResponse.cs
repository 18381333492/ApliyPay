using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// KoubeiTradeItemBuyResponse.
    /// </summary>
    public class KoubeiTradeItemBuyResponse : AopResponse
    {
    }
}
