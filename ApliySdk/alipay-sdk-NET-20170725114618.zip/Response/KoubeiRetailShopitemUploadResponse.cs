using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// KoubeiRetailShopitemUploadResponse.
    /// </summary>
    public class KoubeiRetailShopitemUploadResponse : AopResponse
    {
    }
}
