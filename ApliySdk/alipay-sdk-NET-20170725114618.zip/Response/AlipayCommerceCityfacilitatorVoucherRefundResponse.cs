using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayCommerceCityfacilitatorVoucherRefundResponse.
    /// </summary>
    public class AlipayCommerceCityfacilitatorVoucherRefundResponse : AopResponse
    {
    }
}
