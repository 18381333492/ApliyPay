using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayMsaasPromotionCpainfoCreateResponse.
    /// </summary>
    public class AlipayMsaasPromotionCpainfoCreateResponse : AopResponse
    {
    }
}
