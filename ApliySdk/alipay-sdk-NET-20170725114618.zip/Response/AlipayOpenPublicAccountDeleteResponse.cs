using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenPublicAccountDeleteResponse.
    /// </summary>
    public class AlipayOpenPublicAccountDeleteResponse : AopResponse
    {
    }
}
