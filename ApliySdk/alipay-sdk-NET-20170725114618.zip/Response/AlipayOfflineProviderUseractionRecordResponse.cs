using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOfflineProviderUseractionRecordResponse.
    /// </summary>
    public class AlipayOfflineProviderUseractionRecordResponse : AopResponse
    {
    }
}
