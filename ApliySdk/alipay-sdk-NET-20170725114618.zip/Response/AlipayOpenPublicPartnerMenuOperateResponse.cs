using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenPublicPartnerMenuOperateResponse.
    /// </summary>
    public class AlipayOpenPublicPartnerMenuOperateResponse : AopResponse
    {
    }
}
