using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayEcoMycarParkingConfigSetResponse.
    /// </summary>
    public class AlipayEcoMycarParkingConfigSetResponse : AopResponse
    {
    }
}
