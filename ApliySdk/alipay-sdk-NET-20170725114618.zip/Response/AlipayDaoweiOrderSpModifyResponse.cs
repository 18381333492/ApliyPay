using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayDaoweiOrderSpModifyResponse.
    /// </summary>
    public class AlipayDaoweiOrderSpModifyResponse : AopResponse
    {
    }
}
