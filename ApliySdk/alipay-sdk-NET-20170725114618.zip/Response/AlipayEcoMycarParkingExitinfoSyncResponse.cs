using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayEcoMycarParkingExitinfoSyncResponse.
    /// </summary>
    public class AlipayEcoMycarParkingExitinfoSyncResponse : AopResponse
    {
    }
}
