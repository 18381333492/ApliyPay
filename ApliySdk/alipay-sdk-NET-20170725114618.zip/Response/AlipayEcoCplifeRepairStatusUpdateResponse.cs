using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayEcoCplifeRepairStatusUpdateResponse.
    /// </summary>
    public class AlipayEcoCplifeRepairStatusUpdateResponse : AopResponse
    {
    }
}
