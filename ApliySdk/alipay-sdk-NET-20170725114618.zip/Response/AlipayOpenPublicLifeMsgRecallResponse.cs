using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenPublicLifeMsgRecallResponse.
    /// </summary>
    public class AlipayOpenPublicLifeMsgRecallResponse : AopResponse
    {
    }
}
