using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenPublicMenuModifyResponse.
    /// </summary>
    public class AlipayOpenPublicMenuModifyResponse : AopResponse
    {
    }
}
