using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// KoubeiMarketingDataCustomreportDeleteResponse.
    /// </summary>
    public class KoubeiMarketingDataCustomreportDeleteResponse : AopResponse
    {
    }
}
