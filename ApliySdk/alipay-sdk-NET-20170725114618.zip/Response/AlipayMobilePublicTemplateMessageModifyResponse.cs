using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayMobilePublicTemplateMessageModifyResponse.
    /// </summary>
    public class AlipayMobilePublicTemplateMessageModifyResponse : AopResponse
    {
    }
}
