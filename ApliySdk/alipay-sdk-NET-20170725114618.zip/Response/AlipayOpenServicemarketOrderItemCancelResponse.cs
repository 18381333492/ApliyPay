using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenServicemarketOrderItemCancelResponse.
    /// </summary>
    public class AlipayOpenServicemarketOrderItemCancelResponse : AopResponse
    {
    }
}
