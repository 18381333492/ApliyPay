using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayMarketingCashlessvoucherTemplateModifyResponse.
    /// </summary>
    public class AlipayMarketingCashlessvoucherTemplateModifyResponse : AopResponse
    {
    }
}
