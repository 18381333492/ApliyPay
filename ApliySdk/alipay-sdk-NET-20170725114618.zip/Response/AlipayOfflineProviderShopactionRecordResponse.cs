using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOfflineProviderShopactionRecordResponse.
    /// </summary>
    public class AlipayOfflineProviderShopactionRecordResponse : AopResponse
    {
    }
}
