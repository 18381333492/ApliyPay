using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// ZhimaOpenAppKeyanLqlCreateResponse.
    /// </summary>
    public class ZhimaOpenAppKeyanLqlCreateResponse : AopResponse
    {
    }
}
