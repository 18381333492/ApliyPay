using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenPublicDefaultExtensionCreateResponse.
    /// </summary>
    public class AlipayOpenPublicDefaultExtensionCreateResponse : AopResponse
    {
    }
}
