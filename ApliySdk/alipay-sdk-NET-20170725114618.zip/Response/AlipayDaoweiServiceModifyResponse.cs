using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayDaoweiServiceModifyResponse.
    /// </summary>
    public class AlipayDaoweiServiceModifyResponse : AopResponse
    {
    }
}
