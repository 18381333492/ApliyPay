using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayDaoweiOrderRefuseResponse.
    /// </summary>
    public class AlipayDaoweiOrderRefuseResponse : AopResponse
    {
    }
}
