using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayMobileStdPublicMessageCustomSendResponse.
    /// </summary>
    public class AlipayMobileStdPublicMessageCustomSendResponse : AopResponse
    {
    }
}
