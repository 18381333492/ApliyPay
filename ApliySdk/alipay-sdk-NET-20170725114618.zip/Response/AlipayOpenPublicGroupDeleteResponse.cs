using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenPublicGroupDeleteResponse.
    /// </summary>
    public class AlipayOpenPublicGroupDeleteResponse : AopResponse
    {
    }
}
