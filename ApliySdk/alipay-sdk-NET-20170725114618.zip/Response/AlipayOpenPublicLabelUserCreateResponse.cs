using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenPublicLabelUserCreateResponse.
    /// </summary>
    public class AlipayOpenPublicLabelUserCreateResponse : AopResponse
    {
    }
}
