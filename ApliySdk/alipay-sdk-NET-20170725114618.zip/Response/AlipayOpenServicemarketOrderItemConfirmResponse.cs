using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenServicemarketOrderItemConfirmResponse.
    /// </summary>
    public class AlipayOpenServicemarketOrderItemConfirmResponse : AopResponse
    {
    }
}
