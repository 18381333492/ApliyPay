using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayEcoMycarParkingParkinglotinfoUpdateResponse.
    /// </summary>
    public class AlipayEcoMycarParkingParkinglotinfoUpdateResponse : AopResponse
    {
    }
}
