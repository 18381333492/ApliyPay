using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayDaoweiSpScheduleModifyResponse.
    /// </summary>
    public class AlipayDaoweiSpScheduleModifyResponse : AopResponse
    {
    }
}
