using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayEcoMycarPromoTicketSyncResponse.
    /// </summary>
    public class AlipayEcoMycarPromoTicketSyncResponse : AopResponse
    {
    }
}
