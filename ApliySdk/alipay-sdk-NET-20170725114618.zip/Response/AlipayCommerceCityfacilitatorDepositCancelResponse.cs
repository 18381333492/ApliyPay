using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayCommerceCityfacilitatorDepositCancelResponse.
    /// </summary>
    public class AlipayCommerceCityfacilitatorDepositCancelResponse : AopResponse
    {
    }
}
