using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayMarketingCampaignDiscountStatusUpdateResponse.
    /// </summary>
    public class AlipayMarketingCampaignDiscountStatusUpdateResponse : AopResponse
    {
    }
}
