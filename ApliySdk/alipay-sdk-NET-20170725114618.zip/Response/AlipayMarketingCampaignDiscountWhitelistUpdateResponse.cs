using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayMarketingCampaignDiscountWhitelistUpdateResponse.
    /// </summary>
    public class AlipayMarketingCampaignDiscountWhitelistUpdateResponse : AopResponse
    {
    }
}
