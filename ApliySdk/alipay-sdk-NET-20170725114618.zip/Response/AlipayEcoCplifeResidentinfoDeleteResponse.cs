using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayEcoCplifeResidentinfoDeleteResponse.
    /// </summary>
    public class AlipayEcoCplifeResidentinfoDeleteResponse : AopResponse
    {
    }
}
