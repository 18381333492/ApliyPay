using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayDaoweiServicePriceModifyResponse.
    /// </summary>
    public class AlipayDaoweiServicePriceModifyResponse : AopResponse
    {
    }
}
