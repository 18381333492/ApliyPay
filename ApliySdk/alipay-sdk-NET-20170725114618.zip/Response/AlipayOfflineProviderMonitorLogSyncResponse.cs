using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOfflineProviderMonitorLogSyncResponse.
    /// </summary>
    public class AlipayOfflineProviderMonitorLogSyncResponse : AopResponse
    {
    }
}
