using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayCommerceCityfacilitatorDepositConfirmResponse.
    /// </summary>
    public class AlipayCommerceCityfacilitatorDepositConfirmResponse : AopResponse
    {
    }
}
