using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayMarketingCardFormtemplateSetResponse.
    /// </summary>
    public class AlipayMarketingCardFormtemplateSetResponse : AopResponse
    {
    }
}
