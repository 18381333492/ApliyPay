using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenWangyanTestDeleteResponse.
    /// </summary>
    public class AlipayOpenWangyanTestDeleteResponse : AopResponse
    {
    }
}
