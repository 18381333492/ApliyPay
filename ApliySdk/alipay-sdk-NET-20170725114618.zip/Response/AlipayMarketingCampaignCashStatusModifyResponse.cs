using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayMarketingCampaignCashStatusModifyResponse.
    /// </summary>
    public class AlipayMarketingCampaignCashStatusModifyResponse : AopResponse
    {
    }
}
