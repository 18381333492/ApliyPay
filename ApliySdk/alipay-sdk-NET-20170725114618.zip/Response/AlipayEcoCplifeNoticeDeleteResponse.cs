using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayEcoCplifeNoticeDeleteResponse.
    /// </summary>
    public class AlipayEcoCplifeNoticeDeleteResponse : AopResponse
    {
    }
}
