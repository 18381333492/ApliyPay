using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOpenPublicPartnerSubscribeSyncResponse.
    /// </summary>
    public class AlipayOpenPublicPartnerSubscribeSyncResponse : AopResponse
    {
    }
}
