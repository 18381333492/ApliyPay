﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Aop.Api
{
    class ResponseParseItem
    {

        public string realContent;

        public string respContent;

    }
}
